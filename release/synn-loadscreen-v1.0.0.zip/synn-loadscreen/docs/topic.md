
# Synn's simple loadingscreen

Hello, I've been working on a simple loading screen for about a week. My goal was to set up a loadingscreen that was configurable, easy to  setup and mostly multi-stage loadingbars.
I hope you find this release handy, if you have any issues or feature requests, let me know.

## Features

- Progressbar  
    - Can have multiple progress bars for each type.
    - Can have single progress bars for all types

- Loading screen image
- Rotating loading messages
- All of the above can be edited in the config.

## Planned
 
- Music player
    - Can be stopped/paused.
	- Volume controls